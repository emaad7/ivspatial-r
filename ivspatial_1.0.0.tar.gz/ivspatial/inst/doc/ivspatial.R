## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
has_sf <- requireNamespace("sf", quietly = TRUE)

## -----------------------------------------------------------------------------
library(ivspatial)
g <- lattice_from_indices(mercer_hall$row, mercer_hall$col, "rook")
g

## -----------------------------------------------------------------------------
res <- spatial_test(mercer_hall$grain, g, B = 999, seed = 1, label = "grain")
res

## -----------------------------------------------------------------------------
res$p_value
res$components[, c("name", "statistic", "p_value")]
as.data.frame(res)[, 1:5]

## -----------------------------------------------------------------------------
gk <- knn_graph(cbind(baltimore$X, baltimore$Y), k = 4)
spatial_test(log(baltimore$PRICE), gk, B = 999, seed = 1, features = FALSE)

## -----------------------------------------------------------------------------
r <- residual_test(log(baltimore$PRICE), baltimore[, c("NROOM", "NBATH", "SQFT", "AGE")], gk,
                   B = 999, seed = 1)
r$p_value
r$features

## -----------------------------------------------------------------------------
screen_variables(mercer_hall, g, columns = c("grain", "straw"), B = 999, seed = 1)

## ----eval = has_sf------------------------------------------------------------
nc <- read_polygons(system.file("shape/nc.shp", package = "sf"))
gq <- polygon_graph(nc, "queen")
gq
spatial_test(1000 * nc$SID79 / nc$BIR79, gq, B = 999, seed = 1, features = FALSE)

## ----fig.width = 9, fig.height = 3.4------------------------------------------
map_local(mercer_hall$grain, lattice_graph(20, 25))

## -----------------------------------------------------------------------------
a <- spatial_test(mercer_hall$straw, g, B = 499, seed = 1, resolution = "auto", features = FALSE,
                  asymptotic = FALSE)
a$selected
a$p_value

## -----------------------------------------------------------------------------
null_limit(g, d = 4, s = 2, value = 35)

